﻿// See https://aka.ms/new-console-template for more information
using ConsoleApp6;

FileManager fm = new FileManager(new MyDirectory());
fm.delete();
