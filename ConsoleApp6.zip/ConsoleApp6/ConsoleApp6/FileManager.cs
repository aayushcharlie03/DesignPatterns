﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    public class FileManager
    {
        private IOComponent _ioInterface; 
        public FileManager(IOComponent io)
        {
            _ioInterface = io;
        }

        public int getSize()
        {
            return _ioInterface.getSize();
        }

        public void delete()
        {
            _ioInterface.delete();
        }

    }

}
