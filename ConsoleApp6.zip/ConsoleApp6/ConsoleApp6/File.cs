﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    public class File : IOComponent
    {
        public void delete()
        {

        }

        public int getSize()
        {
            return 0;
        }
    }
}
