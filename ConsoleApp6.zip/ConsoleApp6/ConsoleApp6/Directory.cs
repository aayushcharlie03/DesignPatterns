﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    public class MyDirectory : IOComponent
    {
        List<IOComponent> Components;

        public void AddToIOComponent(IOComponent component)
        {
            Components.Add(component);
        }

        public void RemoveIOComponent(IOComponent component)
        {
            Components.Remove(component);
        }
        public void delete()
        {

        }

        public int getSize()
        {
            int size = 0;
            foreach (var component in Components)
            {
                size = size + component.getSize();
            }
            return size;
        }
    }
}
